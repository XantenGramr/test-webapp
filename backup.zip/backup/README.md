# Log Check

## Development
=> Compilaton
    -> npm run compile 
        ** one time compile
    -> npm run watch
        ** compile every file change
=> F5 or Start Debugging command

## How to Use
-> Open VsCode User Settings
    - set grep command
    - set mkdir commmand
    - set cat command
  -> Note : for mobaxterm use the commands in the slash directory (Ex. C:\.opt\MobaXterm\slash\bin\cat.exe)


