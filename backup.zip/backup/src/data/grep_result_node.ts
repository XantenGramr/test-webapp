import path from 'path';
import * as vscode from 'vscode';

export class GrepResult extends vscode.TreeItem {
    children: GrepResult[] | undefined;
    name: string;
    filename: string;
    parent: string;
    filePath: string;
    regex: string;
    rootPath: string;

    constructor(label: string, name: string, filename: string, parent: string, filePath: string) {
      super(label, vscode.TreeItemCollapsibleState.None);
      this.tooltip  = `Grep : ${filename}`;
      this.description = "";
      this.name = name;
      this.filename = filename;
      this.parent = parent;
      this.filePath = filePath;
      this.contextValue = "grepResult";
      this.rootPath = path.join(filePath, filename);
    
      this.children = [];
    }

    public addRegex(regex: string) {
        this.regex = regex;
    }

    public addGrepResult(result: GrepResult) {
        result.tooltip = `${this.tooltip} -> ${result.regex}`;
        result.rootPath = this.rootPath;

        this.children?.push(result);

        this.collapsibleState = vscode.TreeItemCollapsibleState.Expanded;
    }
};

