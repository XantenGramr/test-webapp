import path from 'path';
import { Settings } from '../env/settings';
import { GrepResult } from './grep_result_node';
import { generateHash } from '../utils/hash';
import { ResultTreeViewProvider } from '../view/result_tree_view_provider';
import { Bookmark } from './bookmark';
import { BookmarkTreeViewProvider } from '../view/bookmark_tree_view_provider';

const DELIMITER = "-";

class NameData {
    root: string;
    addresses: number[];

    constructor(name: string) {
        const tokens: string[] = name.split(DELIMITER);

        this.root = tokens[0];
        this.addresses = [];
        for ( let i = 1; i < tokens.length; ++i) {
            this.addresses.push(parseInt(tokens[i]));
        }
    }
}

export class GrepResultManager {
  private static instance: GrepResultManager;
  private rootNodes: GrepResult[] = [];
  private bookmarks: Bookmark[] = [];
  private childrenCount: Record<string, number> = {};

  private constructor() {}

  public static getInstance(): GrepResultManager {
    if (!GrepResultManager.instance) {
      GrepResultManager.instance = new GrepResultManager();
    }
    return GrepResultManager.instance;
  }

    public getBookmarks(): Bookmark[] {
        return this.bookmarks;
    }

    public getNodes(): GrepResult[] {
        return this.rootNodes;
    }

    public getNextName(filePath: string, regex: string): GrepResult {
        let basename = path.parse(filePath).base;
        let diretory = path.parse(filePath).dir;
        let filename = path.parse(filePath).name;
        let extensionName = path.parse(filePath).ext;

        let hash = "";
        if (this.isOriginalFile(extensionName)) {
            hash = generateHash(filename).slice(0,8);
            this.createRootNodeIfNotExist(hash, basename, diretory);
        } else {
            hash = filename;
        }

        let nextNode = new GrepResult(
            regex,
            this.prepareNextName(hash),
            this.prepareNextName(hash)+".grepresult",
            hash,
            Settings.getInstance().getResultsWorkspace(),
            );
        
        nextNode.addRegex(regex);

        return nextNode;
    }

    public addBookmark(filePath: string, lineNumber: number) {
        let basename = path.parse(filePath).base;
        let diretory = path.parse(filePath).dir;
        let filename = path.parse(filePath).name;
        let extensionName = path.parse(filePath).ext;

        let hash = "";
        if (this.isOriginalFile(extensionName)) {
            hash = generateHash(filename).slice(0,8);
            this.createRootNodeIfNotExist(hash, basename, diretory);
        } else {
            hash = filename;
        }

        let nameData = new NameData(hash);

        let bookmark = new Bookmark(`linenumber:${lineNumber}`, nameData.root, lineNumber);
        let currentNode;
        for ( let n of this.bookmarks ) {
            if (n.name === nameData.root) {
                currentNode = n;
                break;
            }
        }

        let rootNode;
        for (let n of this.rootNodes) {
            if (n.name === nameData.root) {
                rootNode = n;
                break;
            }
        }

        currentNode.addBookmark(bookmark);

        BookmarkTreeViewProvider.getInstance().refresh();
    }

    public getRootPath(name: string) : string {
        let rootNode;
        for (let n of this.rootNodes) {
            if (n.name === name) {
                rootNode = n;
                break;
            }
        }

        return rootNode.rootPath;
    }

    public saveOutput(node: GrepResult) {

        let nameData = new NameData(node.parent);
        let currentNode;
        for ( let n of this.rootNodes ) {
            if (n.name === nameData.root) {
                currentNode = n;
                break;
            }
        }

        for ( let a of nameData.addresses) {
            let children: GrepResult[] = currentNode.children;
            currentNode = children.at(a - 1);
        }

        // currentNode.children.push(node);
        currentNode.addGrepResult(node);
    
        if (node.parent in this.childrenCount) {
            ++(this.childrenCount[node.parent]);
        } else {
            this.childrenCount[node.parent] = 1;
        }
        ResultTreeViewProvider.getInstance().refresh();
    }

    public isRootFile(filePath: string): boolean {
        let extensionName = path.parse(filePath).ext;

        if (this.isOriginalFile(extensionName)) {
            return true;
        }

        return false;
    }

    private createRootNodeIfNotExist(name: string, filename: string, directory: string) {
        for ( let n of this.rootNodes ) {
            if (n.name === name) {
                return;
            }
        }

        let node = new GrepResult(filename, name, filename, "", directory);
        this.rootNodes.push(node);

        let bookmark = new Bookmark(filename, name, 0);
        this.bookmarks.push(bookmark);

        ResultTreeViewProvider.getInstance().refresh();
        BookmarkTreeViewProvider.getInstance().refresh();
    }

  private prepareNextName(name: string): string {
    let count = 1;
    if (name in this.childrenCount) {
        count = this.childrenCount[name] + 1;
    }

    return `${name}${this.generateSuffix(count)}`;
  }

    private generateSuffix(count: number): string {
        return `${DELIMITER}${count}`;
    }

    private isOriginalFile(fileType: string): boolean {
        if (fileType === ".grepresult") {
            return false;
        }

        return true;
    }
}
