import * as vscode from 'vscode';

export class Bookmark extends vscode.TreeItem {
    children: Bookmark[] | undefined;
    name: string;
    lineNumber: number;

    constructor(label: string, name: string, lineNumber: number) {
      super(label, vscode.TreeItemCollapsibleState.None);
      this.tooltip  = `Bookmark `;
      this.description = "";
      this.name = name;
      this.lineNumber = lineNumber;
    
      this.children = [];
    }

    public addBookmark(bookmark: Bookmark) {
        bookmark.contextValue = "bookmark";
        this.children?.push(bookmark);
        this.collapsibleState = vscode.TreeItemCollapsibleState.Expanded;
    }
};

