import path from "path";
import { generateHash } from "../utils/hash";
import { Logger } from "../utils/logger";
import * as vscode from "vscode";

export class Settings {
    private static _instance: Settings;

    private tempDirectory: string;
    private resultsWorkspace: string;
    private codeWorkspace: string | undefined;
    private hash: string;

    private grepCommand: string = "";
    private catCommand: string = "";
    private mkdirCommand: string = "";

    public static getInstance(): Settings {
        if (!Settings._instance) {
            Settings._instance = new Settings();
        }
        return Settings._instance;
    }

    public getGrepCommand(): string {
        return this.grepCommand;
    }

    public getCatCommand(): string {
        return this.catCommand;
    }

    public getMkdirCommand(): string {
        return this.mkdirCommand;
    }

    public getResultsWorkspace(): string {
        return this.resultsWorkspace;
    }

    private constructor() {
        // use path instead of string
        if (process.platform === "linux") {
            this.tempDirectory = "/tmp";
        } else {
            // For windows
            this.tempDirectory = `${process.env.LOCALAPPDATA}`;
        }

        if (vscode.workspace.workspaceFolders?.[0].uri.fsPath) {
            this.codeWorkspace = vscode.workspace.workspaceFolders?.[0].uri.fsPath;
        } else {
            this.codeWorkspace = "";
        }
        
        this.hash = generateHash(this.codeWorkspace);
        this.resultsWorkspace = path.join(this.tempDirectory, "grep_results", this.hash);
        // this.resultsWorkspace = this.tempDirectory+"\\"+this.hash;

        Logger.log("tempDirectory : "+this.tempDirectory);
        Logger.log("codeWorkspace : "+this.codeWorkspace);
        
        Logger.log("resultsWorkspace : "+this.resultsWorkspace);


        const config = vscode.workspace.getConfiguration('extension');

        const grepCommand = config.get<string>('grepCommand');
        if(grepCommand !== undefined) {
            this.grepCommand = grepCommand;
        }
        const catCommand = config.get<string>('catCommand');
        if(catCommand !== undefined) {
            this.catCommand = catCommand;
        }
        const mkdirCommand = config.get<string>('mkdirCommand');
        if(mkdirCommand !== undefined) {
            this.mkdirCommand = mkdirCommand;
        }

    }
}

