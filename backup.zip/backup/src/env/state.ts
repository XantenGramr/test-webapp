export class State {
    private static _instance: State;

    private _isActive: boolean;

    public static getInstance(): State {
        if (!State._instance) {
            State._instance = new State();
        }
        return State._instance;
    }

    public isActive(): boolean {
        return this._isActive;
    }

    public setState(isActive: boolean) {
        this._isActive = isActive;
    }

    private constructor() {
        this._isActive = false;
    }
}
