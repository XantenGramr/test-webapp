import * as vscode from 'vscode';
import { GrepFile } from './commands/grep_file';
import { WorkspaceSetup } from './commands/workspace_setup';
import { TestCases } from './commands/test_cases';
import { ViewTreeItem } from './commands/view_tree_item';
import { AddBookmark } from './commands/add_bookmark';
import { GoToBookmark } from './commands/go_to_bookmark';

export class CommandRegistration {
    private context: vscode.ExtensionContext;
    private commands = [
        new WorkspaceSetup("extension.workspaceSetup"),
        new GrepFile("extension.testGrep"),
        new AddBookmark("extension.addBookmark"),
        new TestCases("extension.grepTestCase"),
    ];

    private viewCommands = [
        new ViewTreeItem("extension.treeItemView"),
        new GoToBookmark("extension.goToLine"),
    ];

    constructor(context: vscode.ExtensionContext) {
        this.context = context;
    }

    public register() {
        for (let command of this.commands) {
            vscode.commands.registerCommand(command.getName(), command.trigger.bind(command));
        }
        for (let command of this.viewCommands) {
            vscode.commands.registerCommand(command.getName(), command.trigger.bind(command));
        }
    }
}