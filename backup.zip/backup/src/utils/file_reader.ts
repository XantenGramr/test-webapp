import * as fs from 'fs';
import * as readline from 'readline';

export class FileReader {

    public static async getClosestLineNumber(filePath: string, targetNumber: number): Promise<number>{
        
        const fileStream = fs.createReadStream(filePath);

        const rl = readline.createInterface({
            input: fileStream,
            crlfDelay: Infinity,
        })

        let result = 0;
        for await (const line of rl) {
            const match = line.match(/^(\d+):\s*(.*)$/);
            if (match) {
                const lineNumber = parseInt(match[1], 10); // 1-based line number
                
                if (lineNumber >= targetNumber) {
                    break;
                }
                
            }
            ++result;
        }


        return result;
    }
}


