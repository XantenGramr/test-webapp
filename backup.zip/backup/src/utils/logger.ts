import * as vscode from 'vscode';

// let outputChannel: vscode.OutputChannel | undefined;
// let logger: undefined;

export class Logger {
    static outputChannel: vscode.OutputChannel | undefined;
    
    static log(message: string | undefined) {
        if (Logger.outputChannel === undefined) {
            Logger.outputChannel = vscode.window.createOutputChannel('My Exntension', 'Log');
        }

        Logger.outputChannel.appendLine(`${message}`);
    }
}

