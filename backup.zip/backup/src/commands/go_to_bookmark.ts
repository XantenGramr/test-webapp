import * as vscode from 'vscode';
import * as fs from 'fs/promises';
import { VsCodeViewCommand } from './abstract_view_command';
import path from 'path';
import { GrepResult } from '../data/grep_result_node';
import { Bookmark } from '../data/bookmark';
import { GrepResultManager } from '../data/results_manager';
import { FileReader } from '../utils/file_reader';
import { Logger } from '../utils/logger';


export class GoToBookmark extends VsCodeViewCommand {
    async trigger(item: Bookmark): Promise<void> {
        const activeTab = vscode.window.tabGroups.activeTabGroup.activeTab;
        const sourceUri = (activeTab?.input as any)?.uri as vscode.Uri | undefined;
        const label = (activeTab?.input as any)?.label as string | undefined;

        if (sourceUri === undefined) {
            Logger.log("File not found");
        }

        const uriPath = sourceUri?.fsPath;
        // const path = sourceUri?.path;
        const manager = GrepResultManager.getInstance();

        let line = 0;
        if (manager.isRootFile(uriPath)) {
            line = item.lineNumber - 1;
        } else {
            line = await FileReader.getClosestLineNumber(uriPath, item.lineNumber);
        }



        // const path = GrepResultManager.getInstance().getRootPath(item.name);
        vscode.window.showInformationMessage(`go to ${path} - ${item.lineNumber}`);
        const uri = vscode.Uri.file(uriPath);


        await vscode.commands.executeCommand('vscode.open', uri, {
            selection: new vscode.Range(new vscode.Position(line, 0), new vscode.Position(line,10))
        });
    }

    private sleep(ms: number): Promise<void> {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}

