import * as vscode from 'vscode';
import * as fs from 'fs/promises';
import { VsCodeViewCommand } from './abstract_view_command';
import path from 'path';
import { GrepResult } from '../data/grep_result_node';


export class ViewTreeItem extends VsCodeViewCommand {
    async trigger(item: GrepResult): Promise<void> {
        // vscode.window.showInformationMessage(`Button clicked for ${item.label}`);
        let retries = 0;
        const MAX_RETRIES = 15;
        let errorMessage = "";
        let isOk = false;
        // 'c:\\.workspace\\kona\\DF250704-00804-poweroffon-tpsoc\\hyperuart_SDB01_250704_151248_TPSOC_ERR()\\checklogs\\hyperuart_SDB01.txt'
        const file = path.join(item.filePath, item.filename);

        while(retries < MAX_RETRIES) {
            const uri = vscode.Uri.file(file);

            try {
                await fs.access(file);
                await vscode.commands.executeCommand('vscode.open', uri);
                // const doc = await vscode.workspace.openTextDocument(uri);
                // await vscode.window.showTextDocument(doc, { preview: false});
                isOk = true;
                break;
            } catch( error ) {
                errorMessage = `Could not open file : ${error}`;
            }

            ++retries;
            await this.sleep(1000);
        }
    }

    private sleep(ms: number): Promise<void> {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}

