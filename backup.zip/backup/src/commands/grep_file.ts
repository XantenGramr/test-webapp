import * as vscode from 'vscode';
import * as fs from 'fs/promises';
import { exec } from 'child_process';
import { VsCodeCommand } from "./abstract_command";
import { Logger } from '../utils/logger';
import { Settings } from '../env/settings';
import { GrepResultManager } from '../data/results_manager';

export class GrepFile extends VsCodeCommand {
    async trigger(): Promise<void> {
        const activeTab = vscode.window.tabGroups.activeTabGroup.activeTab;
        const sourceUri = (activeTab?.input as any)?.uri as vscode.Uri | undefined;
        const label = (activeTab?.input as any)?.label as string | undefined;

        if (sourceUri === undefined) {
            Logger.log("File not found");
        }

        const uriPath = sourceUri?.fsPath;
        const path = sourceUri?.path;
        const manager = GrepResultManager.getInstance();

        const pattern = await vscode.window.showInputBox({ prompt: 'Enter grep pattern (RegExp)' });
        if (!pattern) {return;}

        const newNode = manager.getNextName(uriPath, pattern);
        
        const settings = Settings.getInstance();
        const newFileName = newNode.filename;
        const resultFile = `${settings.getResultsWorkspace()}/${newFileName}`;

        let grepParameters = "";
        if (manager.isRootFile(uriPath)) {
            grepParameters = "-n";
        }

        const commandLines = [
            `${settings.getCatCommand()} "${uriPath}"`,
            ` | ${settings.getGrepCommand()} ${grepParameters} ${pattern}`,
            ` > ${resultFile}`,
        ];

        let cmd = "";
        for ( let commandLine of commandLines) {
            cmd = cmd + commandLine;
        }

        exec(cmd);

        let retries = 0;
        const MAX_RETRIES = 15;
        let errorMessage = "";
        let isOk = false;

        while(retries < MAX_RETRIES) {
            const uri = vscode.Uri.file(resultFile);

            try {
                await fs.access(resultFile);
                await vscode.commands.executeCommand('vscode.open', uri);
                isOk = true;
                break;
            } catch( error ) {
                errorMessage = `Could not open file : ${error}`;
            }

            ++retries;
            await this.sleep(1000);
        }
        
        if (isOk) {
            manager.saveOutput(newNode);
        } else {
            vscode.window.showErrorMessage(errorMessage);
        }

        console.log(vscode.window);
    }

    private sleep(ms: number): Promise<void> {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}

