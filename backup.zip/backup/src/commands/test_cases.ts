import * as vscode from 'vscode';
import { VsCodeCommand } from "./abstract_command";
import { Logger } from '../utils/logger';
import { GrepResultManager } from '../data/results_manager';
import { ResultTreeViewProvider } from '../view/result_tree_view_provider';

export class TestCases extends VsCodeCommand {
    async trigger(): Promise<void> {
        // const activeTab = vscode.window.tabGroups.activeTabGroup.activeTab;
        // const sourceUri = (activeTab?.input as any)?.uri as vscode.Uri | undefined;
        // const label = (activeTab?.input as any)?.label as string | undefined;

        // if (sourceUri === undefined) {
        //     Logger.log("File not found");
        // }

        // if (sourceUri?.fsPath === undefined) {
        //     Logger.log("File not found : fsPath undefined");
        // }
        // const uriPath: string = sourceUri?.fsPath;
        // const path = sourceUri?.path;

        // const manager = GrepResultManager.getInstance();
        // const name1 = manager.getNextName(uriPath);
        // Logger.log(name1.name);
        // manager.saveOutput(name1);

        // const name2 = manager.getNextName(name1.name);
        // manager.saveOutput(name2);

        // ResultTreeViewProvider.getInstance().refresh();


        const activeTab = vscode.window.tabGroups.activeTabGroup.activeTab;
        const sourceUri = (activeTab?.input as any)?.uri as vscode.Uri | undefined;
        const label = (activeTab?.input as any)?.label as string | undefined;

        if (sourceUri === undefined) {
            Logger.log("File not found");
        }

        if (sourceUri?.fsPath === undefined) {
            Logger.log("File not found : fsPath undefined");
        }
        const uriPath: string = sourceUri?.fsPath;
        const path = sourceUri?.path;
        const editors = vscode.window.visibleTextEditors;
        console.log(editors);
        console.log(vscode.window);
        const editor = vscode.window.visibleTextEditors.find(e => e.document.uri.fsPath === uriPath);

        const line = 50000;

        const uri = vscode.Uri.file(uriPath);
        if (editor) {
            const position = new vscode.Position(line, 0);
            editor.revealRange(new vscode.Range(position, position), vscode.TextEditorRevealType.AtTop);
            editor.selection = new vscode.Selection(position, position);
        }
        else {
            await vscode.commands.executeCommand('vscode.open', uri, {
                selection: new vscode.Range(new vscode.Position(line, 0), new vscode.Position(line,0))
            });
        }

    }
}

