import * as vscode from 'vscode';
import * as fs from 'fs/promises';
import { exec } from 'child_process';
import { VsCodeCommand } from "./abstract_command";
import { Logger } from '../utils/logger';
import { Settings } from '../env/settings';
import { GrepResultManager } from '../data/results_manager';

export class AddBookmark extends VsCodeCommand {
    async trigger(): Promise<void> {
        const activeTab = vscode.window.tabGroups.activeTabGroup.activeTab;
        const sourceUri = (activeTab?.input as any)?.uri as vscode.Uri | undefined;
        const label = (activeTab?.input as any)?.label as string | undefined;

        if (sourceUri === undefined) {
            Logger.log("File not found");
        }

        const uriPath = sourceUri?.fsPath;
        const path = sourceUri?.path;
        const manager = GrepResultManager.getInstance();

        const pattern = await vscode.window.showInputBox({ prompt: 'Enter File line number' });
        if (!pattern) {return;}

        const lineNumber = parseInt(pattern);
        const newNode = manager.addBookmark(uriPath, lineNumber);
    }

    private sleep(ms: number): Promise<void> {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}

