import { TreeItem } from "vscode";

export abstract class VsCodeViewCommand {
    name: string;

    constructor(name: string) {
        this.name = name;
    }

    getName(): string {
        return this.name;
    }

    abstract trigger(item: TreeItem): void;    
}
