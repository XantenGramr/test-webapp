import * as vscode from 'vscode';
import { exec } from 'child_process';
import { VsCodeCommand } from "./abstract_command";
import { Logger } from '../utils/logger';
import { Settings } from '../env/settings';
import { State } from '../env/state';
import { ResultTreeViewProvider } from '../view/result_tree_view_provider';
import { BookmarkTreeViewProvider } from '../view/bookmark_tree_view_provider';

export class WorkspaceSetup extends VsCodeCommand {
    trigger(): void {
        const settings = Settings.getInstance();
        const prepareDirectoryCommand = `${settings.getMkdirCommand()} -p ${settings.getResultsWorkspace()}`;

        Logger.log(prepareDirectoryCommand);
        exec(`${prepareDirectoryCommand}`);

        // Activate Tree View Provider
        const rootPath =
            vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders.length > 0
            ? vscode.workspace.workspaceFolders[0].uri.fsPath
            : undefined;

        const resultTreeDataProvider = ResultTreeViewProvider.getInstance();
        vscode.window.registerTreeDataProvider('grepSummary', resultTreeDataProvider);

        const bookmarkTreeViewProvider = BookmarkTreeViewProvider.getInstance();
        vscode.window.registerTreeDataProvider('bookmarksView', bookmarkTreeViewProvider);
        
        State.getInstance().setState(true);
    }
}

