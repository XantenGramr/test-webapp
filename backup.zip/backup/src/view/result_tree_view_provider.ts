import * as vscode from 'vscode';
import { GrepResult } from '../data/grep_result_node';
import { GrepResultManager } from '../data/results_manager';

export class ResultTreeViewProvider implements vscode.TreeDataProvider<GrepResult> {
    private static _instance: ResultTreeViewProvider;   
    data: GrepResult[];

    public static getInstance(): ResultTreeViewProvider {
        if (!ResultTreeViewProvider._instance) {
            ResultTreeViewProvider._instance = new ResultTreeViewProvider();
        }

        return ResultTreeViewProvider._instance;
    }

    private constructor() {
      
      this.data = [
        // new GrepResult("test", "test", "test", "test"),
      ];
    }

    getTreeItem(element: GrepResult): vscode.TreeItem | Thenable<vscode.TreeItem> {
      return element;
    }
  
    getChildren(element?: GrepResult | undefined): vscode.ProviderResult<GrepResult[]> {
      if (element === undefined) {
        return this.data;
      }

      return element.children;
    }

    private _onDidChangeTreeData: vscode.EventEmitter<GrepResult | undefined | null | void> = new vscode.EventEmitter<GrepResult | undefined | null | void>();
    onDidChangeTreeData?: vscode.Event<void | GrepResult | GrepResult[] | null | undefined> | undefined = this._onDidChangeTreeData.event;

    refresh(): void {
      this.data = GrepResultManager.getInstance().getNodes();
      this._onDidChangeTreeData.fire();
    }
}

