import * as vscode from 'vscode';
import { Bookmark } from '../data/bookmark';
import { GrepResultManager } from '../data/results_manager';

export class BookmarkTreeViewProvider implements vscode.TreeDataProvider<Bookmark> {
    private static _instance: BookmarkTreeViewProvider;   
    data: Bookmark[];

    public static getInstance(): BookmarkTreeViewProvider {
        if (!BookmarkTreeViewProvider._instance) {
          BookmarkTreeViewProvider._instance = new BookmarkTreeViewProvider();
        }

        return BookmarkTreeViewProvider._instance;
    }

    private constructor() {
      
      this.data = [
        // new Bookmark("test", "test", "test", "test"),
      ];
    }

    getTreeItem(element: Bookmark): vscode.TreeItem | Thenable<vscode.TreeItem> {
      return element;
    }
  
    getChildren(element?: Bookmark | undefined): vscode.ProviderResult<Bookmark[]> {
      if (element === undefined) {
        return this.data;
      }

      return element.children;
    }

    private _onDidChangeTreeData: vscode.EventEmitter<Bookmark | undefined | null | void> = new vscode.EventEmitter<Bookmark | undefined | null | void>();
    onDidChangeTreeData?: vscode.Event<void | Bookmark | Bookmark[] | null | undefined> | undefined = this._onDidChangeTreeData.event;

    refresh(): void {
      this.data = GrepResultManager.getInstance().getBookmarks();
      this._onDidChangeTreeData.fire();
    }
}

