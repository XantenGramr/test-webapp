import { exec } from 'child_process';
import * as vscode from 'vscode';

import { Logger } from './utils/logger';
import { Settings } from './env/settings';

import { ResultTreeViewProvider } from './view/result_tree_view_provider';
import { CommandRegistration } from './command_registration';
import { State } from './env/state';

class Extension {
    private context: vscode.ExtensionContext;
    private settings: Settings;
    private commandRegistration: CommandRegistration;
    private state: State;

    constructor(context: vscode.ExtensionContext) {
        this.context = context;
        this.settings = Settings.getInstance();
        this.state = State.getInstance();
        this.commandRegistration = new CommandRegistration(this.context);

        this.initialize();
    }

    private initialize() {
        // const treeDataProvider = ResultTreeViewProvider.getInstance();
        // vscode.window.registerTreeDataProvider('grepSummary', treeDataProvider);

        this.commandRegistration.register();
    }
}



export function activate(context: vscode.ExtensionContext) {
    const extension = new Extension(context);
}

export function deactivate() {}

