

export abstract class Singleton<T> {
    protected static instance: any;

    protected constructor() {}

    public static getInstance<T>(this: new () => T & { constructor: typeof Singleton } ): T {
        const cls = this as any;
        if (!cls.instance) {
            cls.instance = new this();
        }
        return cls.instance;
    }
}


