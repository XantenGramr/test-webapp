document.addEventListener('DOMContentLoaded', () => {
  const rows = Array.from(document.querySelectorAll('.carousel'));

  let currentRow = 0;
  let currentColumn = 0;

  const focusItem = (row, col) => {
    const items = rows[row].children;
    if (items[col]) {
      items[col].focus();
    }
  };

  const getMaxColumn = (row) => {
    return rows[row].children.length - 1;
  };

  // Initial focus
  focusItem(currentRow, currentColumn);

  document.addEventListener('keydown', (e) => {
    const maxRow = rows.length - 1;
    const maxCol = getMaxColumn(currentRow);

    switch (e.key) {
      case 'ArrowRight':
        if (currentColumn < maxCol) {
          currentColumn++;
          focusItem(currentRow, currentColumn);
        }
        break;
      case 'ArrowLeft':
        if (currentColumn > 0) {
          currentColumn--;
          focusItem(currentRow, currentColumn);
        }
        break;
      case 'ArrowDown':
        if (currentRow < maxRow) {
          currentRow++;
          currentColumn = Math.min(currentColumn, getMaxColumn(currentRow));
          focusItem(currentRow, currentColumn);
        }
        break;
      case 'ArrowUp':
        if (currentRow > 0) {
          currentRow--;
          currentColumn = Math.min(currentColumn, getMaxColumn(currentRow));
          focusItem(currentRow, currentColumn);
        }
        break;
    }
  });
});
