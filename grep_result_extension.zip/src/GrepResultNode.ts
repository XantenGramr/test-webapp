import * as vscode from 'vscode';

export class GrepResultNode extends vscode.TreeItem {
  public children: GrepResultNode[] = [];

  constructor(
    public readonly name: string,
    public readonly outputPath: string,
    public readonly parent?: GrepResultNode
  ) {
    super(name, children.length > 0 ? vscode.TreeItemCollapsibleState.Collapsed : vscode.TreeItemCollapsibleState.None);
    this.tooltip = outputPath;
    this.resourceUri = vscode.Uri.file(outputPath);
    this.contextValue = 'grepResult';
  }

  public addChild(child: GrepResultNode) {
    this.children.push(child);
    this.collapsibleState = vscode.TreeItemCollapsibleState.Collapsed;
  }
}