import * as vscode from 'vscode';
import { GrepTreeProvider } from './GrepTreeProvider';
import { GrepResultManager } from './GrepResultManager';

export function activate(context: vscode.ExtensionContext) {
  const grepTreeProvider = new GrepTreeProvider();
  vscode.window.registerTreeDataProvider('grepResults', grepTreeProvider);

  context.subscriptions.push(
    vscode.commands.registerCommand('extension.addGrepResult', () => {
      const manager = GrepResultManager.getInstance();
      const base = 'abc123';
      const name1 = manager.getNextName(base);
      manager.saveOutput(name1, `/tmp/${name1}.grepresult`);

      const name2 = manager.getNextName(name1);
      manager.saveOutput(name2, `/tmp/${name2}.grepresult`);

      grepTreeProvider.refresh();
    })
  );
}

export function deactivate() {}