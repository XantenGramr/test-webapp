import * as vscode from 'vscode';
import { GrepResultNode } from './GrepResultNode';
import { GrepResultManager } from './GrepResultManager';

export class GrepTreeProvider implements vscode.TreeDataProvider<GrepResultNode> {
  private _onDidChangeTreeData = new vscode.EventEmitter<GrepResultNode | undefined>();
  readonly onDidChangeTreeData = this._onDidChangeTreeData.event;

  refresh(): void {
    this._onDidChangeTreeData.fire(undefined);
  }

  getTreeItem(element: GrepResultNode): vscode.TreeItem {
    return element;
  }

  getChildren(element?: GrepResultNode): Thenable<GrepResultNode[]> {
    const manager = GrepResultManager.getInstance();
    if (element) {
      return Promise.resolve(manager.getChildren(element));
    } else {
      return Promise.resolve(manager.getRoots());
    }
  }
}