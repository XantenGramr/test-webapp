import { GrepResultNode } from './GrepResultNode';

export class GrepResultManager {
  private static instance: GrepResultManager;
  private rootNodes: GrepResultNode[] = [];
  private nodeMap = new Map<string, GrepResultNode>();

  private constructor() {}

  public static getInstance(): GrepResultManager {
    if (!GrepResultManager.instance) {
      GrepResultManager.instance = new GrepResultManager();
    }
    return GrepResultManager.instance;
  }

  public getNextName(parentName: string): string {
    const siblings = Array.from(this.nodeMap.keys()).filter(k => k.startsWith(`${parentName}-`));
    let maxSuffix = 0;

    for (const name of siblings) {
      const match = name.match(/(\d+)(?!.*\d)/);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > maxSuffix) maxSuffix = num;
      }
    }

    return `${parentName}-${maxSuffix + 1}`;
  }

  public saveOutput(name: string, outputPath: string): GrepResultNode {
    const parentName = this.getParentName(name);
    const parentNode = this.nodeMap.get(parentName);
    const newNode = new GrepResultNode(name, outputPath, parentNode);

    if (parentNode) {
      parentNode.addChild(newNode);
    } else {
      this.rootNodes.push(newNode);
    }

    this.nodeMap.set(name, newNode);
    return newNode;
  }

  public getRoots(): GrepResultNode[] {
    return this.rootNodes;
  }

  public getChildren(node: GrepResultNode): GrepResultNode[] {
    return node.children;
  }

  private getParentName(name: string): string | null {
    const parts = name.split('-');
    if (parts.length <= 1) return null;
    return parts.slice(0, -1).join('-');
  }
}